
from .flaskapp import Newsroom

app = Newsroom(__name__)

